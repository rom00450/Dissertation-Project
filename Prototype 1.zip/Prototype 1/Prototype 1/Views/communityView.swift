//
//  communityView.swift
//  Prototype 1
//
//  Created by Roberto Martin on 13/11/2024.
//

import SwiftUI

struct communityView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    communityView()
}



